# ShadeShift presentation sources

This folder contains editable authoring sources for the anonymous judge artifacts.

- `build-deck.mjs`: eight-slide deck, native editable charts/text, real application map image, cited speaker notes.
- `build-brief.py`: five-page methods/results PDF, including equations, evidence, model outputs, sensitivity, cost assumptions and source links.
- `assets/houston-map.png`: actual application screenshot with historical observations and OpenStreetMap attribution.

The PPTX uses `@oai/artifact-tool` and a finalizer that checks package integrity, chart workbook values, fonts, geometry and slide count. It uses Helvetica Neue. The brief uses ReportLab and Arial. To rebuild on a different machine, adjust runtime paths and the ROOT output directory. Each deck revision needs a fresh finalizer filename and receipt path. The finalizer does not overwrite these files.

Current bundled runtime used:

- Node: `/Users/shivamgupta/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node`
- Packages: `/Users/shivamgupta/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules`
- Python: `/Users/shivamgupta/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`
- PDF export: `/Users/shivamgupta/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/soffice` (bundled LibreOffice)

Run the deck with RUNTIME_NODE_MODULES set to the bundled packages directory. The source folder's node_modules link points there. Sources themselves are plain editable files. Do not include the symlink when distributing the authoring source folder.

The final deck was rendered and checked as both Artifact Tool PNGs and bundled LibreOffice PDF. Native PowerPoint was not used. The PDF brief was rendered with Poppler and visually checked on every page.

Quantitative basis: application model v1.0.0, $75,000 cap, 25% community minimum, 22,000 arrivals, 15:00 sunlight factor 1, 100% base effectiveness. Selected spend is $70,000 in both portfolios. Sensitivity holds the optimized portfolio fixed at 60/80/100% effect. Refills are a count of service capacity, not liters. The figures are assumptions-based planning estimates, not measured impact. Pricing hypothesis is consistently $5,000 pilot / $6,000 annual venue license.

For matching PDF export, set FONTCONFIG_FILE to the supplied fonts.conf. It points to the actual macOS font directories and prevents bundled LibreOffice from substituting serif text. Adjust font directories when rebuilding on another platform.
