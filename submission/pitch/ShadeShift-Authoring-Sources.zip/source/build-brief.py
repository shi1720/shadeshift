from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from pathlib import Path
OUT=Path('/tmp/shadeshift-deliverables/output')
FONT='/System/Library/Fonts/Supplemental/'
pdfmetrics.registerFont(TTFont('Arial',FONT+'Arial.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Bold',FONT+'Arial Bold.ttf'))
pdfmetrics.registerFontFamily('Arial',normal='Arial',bold='Arial-Bold',italic='Arial',boldItalic='Arial-Bold')
N=colors.HexColor('#102e36');F=colors.HexColor('#006c59');L=colors.HexColor('#d1f36d');M=colors.HexColor('#54706f');P=colors.HexColor('#f4f7f3')
styles={
 'title':ParagraphStyle('title',fontName='Arial-Bold',fontSize=26,leading=30,textColor=N,spaceAfter=12),
 'sub':ParagraphStyle('sub',fontName='Arial-Bold',fontSize=15,leading=19,textColor=F,spaceBefore=10,spaceAfter=6),
 'body':ParagraphStyle('body',fontName='Arial',fontSize=9.5,leading=13,textColor=N,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='Arial',fontSize=8.5,leading=11.5,textColor=M,spaceAfter=7),
 'cell':ParagraphStyle('cell',fontName='Arial',fontSize=8.8,leading=11.5,textColor=N),
 'head':ParagraphStyle('head',fontName='Arial-Bold',fontSize=8.8,leading=11.5,textColor=colors.white),
 'kicker':ParagraphStyle('kicker',fontName='Arial-Bold',fontSize=9,leading=12,textColor=F,spaceAfter=10),
 'metric':ParagraphStyle('metric',fontName='Arial-Bold',fontSize=22,leading=26,textColor=F,spaceAfter=12)
}
story=[]
def p(t,style='body'): story.append(Paragraph(t,styles[style]))
def title(k,t):p('SHADE SHIFT  /  '+k,'kicker');p(t,'title')
def table(rows,widths):
 data=[[Paragraph(str(v),styles['head' if i==0 else 'cell']) for v in row] for i,row in enumerate(rows)]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),N),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,P]),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#cad7d1'))]))
 story.append(t);story.append(Spacer(1,9))
def page():story.append(PageBreak())
def footer(c,d):
 c.setStrokeColor(F);c.setLineWidth(.6);c.line(48,44,564,44)
 c.setFont('Arial',8);c.setFillColor(M);c.drawString(48,29,'ShadeShift  •  Track 3  •  Methods and results  •  18 September 2026');c.drawRightString(564,29,str(d.page))

title('DECISION AND RESULTS','A funded shade plan for event arrivals')
p('ShadeShift helps venue operators compare shade, queue operations and refill access across six candidate Houston arrival connectors. It addresses Track 3: visitor activity, heat and the built environment. The World Cup is the case study. Recurring games, concerts and festivals are the intended long-term use.')
p('31.25% modeled exposure reduction at $70,000 selected spend','metric')
p('This result comes from a deterministic scenario, not an observed deployment. The $75,000 budget cap and 25% community-weighted investment minimum constrain the allocation. All physical effectiveness and demand inputs remain assumptions until a venue supplies measurements.')
table([['Per modeled event','Starting plan','Optimized plan'],['Selected intervention spend','$70,000','$70,000'],['Baseline direct-sun person-minutes','409,260','409,260'],['Remaining direct-sun person-minutes','311,811.6','281,358'],['Avoided direct-sun person-minutes','97,448.4','127,902'],['Reduction versus baseline','23.81%','31.25%'],['Refill capacity in arrival window','1,200 refills','0 refills'],['Community-weighted investment share','53.29%','27.43%']],[252,132,132])
p('The decision behind the result','sub')
p('The optimized plan selects modular shade at Stadium station, north arrival and Yellow Lot. It selects queue operations at Holly Hall and Kirby, and no intervention at Fannin South. The starting plan includes a refill hub and more investment weighted toward community use. Maximizing one objective changes the service mix, so the operator must review the tradeoff.')
p('Working product','sub')
p('The interactive application links a map, editable assumptions, baseline comparisons, exact portfolio search and effectiveness sensitivity. ChatGPT authentication supports private saved plans in D1. CSV and JSON exports make the plan inspectable. The stack uses Vinext, React, TypeScript, Leaflet and Recharts. Authentication and persistence do not by themselves certify commercial production readiness.')
p('Scope: connector-level planning estimates. Results do not measure citywide outcomes, unique people protected, heat illness avoided or approval to install equipment.','small')
page()
title('METHOD','Exposure accounting and exact allocation')
p('The model deliberately separates temperature context from its objective. It calculates direct-sun person-minutes using demand, duration and shade. It does not estimate a medical risk probability or convert water access into cooling.')
p('Exposure equation','sub')
p('<b>Baseline = N × (W + Q) × (1 − S) × H</b><br/><b>With plan = N × [W + Q × (1 − r × E)] × [1 − min(1, S + a × E)] × H</b>')
p('N is arrivals assigned to a connector, W walking minutes, Q queue minutes, S existing shade fraction, H an illustrative sunlight factor for the chosen hour, E delivered effectiveness, a added shade fraction and r queue-reduction fraction. Avoided exposure equals baseline minus the intervention result, bounded below by zero. The hour profile is an assumption rather than a solar geometry model. At the default 15:00, H = 1.')
p('Allocation and constraints','sub')
p('The six candidate connectors each have five mutually exclusive package choices. Exhaustive search covers a finite catalog of 5<super>6</super> = 15,625 possible portfolios, pruning those over budget. It maximizes total avoided exposure, enforces the minimum community-weighted investment share and chooses lower spend when benefits tie. The verified default run evaluates 2,505 completed portfolios after budget pruning. Exactness applies to this catalog and these assumptions only.')
table([['Package','Initial cost','Assumed change'],['No intervention','$0','Retain baseline'],['Modular shade','$18,000','Add 35 percentage points of shade'],['Shade + refill hub','$26,000','Add shade and capacity for up to 1,200 refills'],['Queue operations','$8,000 / event','Reduce outdoor queue time by 40%'],['Complete cool link','$34,000','Shade, refill hub and queue operations']],[132,111,273])
p('Demand and interpretation','sub')
p('The scenario assigns 22,000 arrivals across six connectors in proportion to demand weights totaling 22,000. These allocations support one modeled arrival window. They are not measured device visits or an empirical origin-destination forecast. Connector geometry is approximate and not a recommended walking route. Field review must address gates, sidewalks, crossings, accessibility and egress.')
p('Community-weighted investment = sum(package cost × assumed local-use share) divided by total spend. It is a transparent planning preference, not a census vulnerability measure or actual transfers to residents. A single package per connector avoids adding overlapping package benefits. A real multi-segment journey still requires an explicit accounting boundary.','small')
page()
title('EVIDENCE','Three evidence levels stay distinct')
table([['Layer','Source and sample','What it supports'],['Measured Houston heat','654 H3AT / CAPA / HARC air-temperature observations, 7 August 2020, 15:00–16:00 local','Historical point context. Partial spatial coverage. No live heat or shade estimate.'],['Transport and venue anchors','Official METRO static GTFS, August2026IVOMS_20260828. Organizer/FIFA venue references.','Stop and venue locations. No live arrivals or approved event gate routing.'],['11-location weather context','ERA5 via Open-Meteo. 49 daily 15:00 local samples per venue, 1 June–19 July 2025','Consistent seasonal comparison. No 2026 forecast, readiness rank or block-scale thermal field.'],['Planning assumptions','Arrivals, dwell, existing shade, package costs/effects and resident reuse inputs','Transparent what-if comparisons, pending operator measurement and quotes.']],[124,210,182])
p('Historical host-location comparison','sub')
table([['Venue region','Median HI °F','95th pct. HI °F'],['Houston','97.8','105.0'],['Dallas','96.8','101.5'],['Miami','93.8','98.7'],['Atlanta','91.5','96.9'],['Philadelphia','90.7','107.8'],['Kansas City','90.4','101.3'],['New York / New Jersey','85.0','102.8'],['Los Angeles','81.2','87.9'],['Boston','80.9','98.4'],['San Francisco Bay Area','76.7','86.5'],['Seattle','70.5','82.4']],[252,132,132])
p('HI denotes derived NWS heat index for shade and light wind. The nearest-rank 95th sample percentile is not a confidence bound. This single 49-day sample is not a climate normal. Approximate stadium coordinates query ERA5 0.25° grids. Persistent and episodic heat differ: Houston has 44/49 sampled afternoons at or above 90°F, while Philadelphia has 26/49 but a higher sampled upper tail. Neither series determines the intervention optimizer.','small')
page()
title('SENSITIVITY AND LIMITS','A result that changes with its assumptions')
p('Effectiveness sensitivity','sub')
p('Hold the optimized portfolio fixed. Apply a common multiplier to added shade and queue-time reduction. Costs and refill capacity do not change. These scenarios test assumptions rather than statistical confidence.')
table([['Delivered effectiveness','Avoided person-minutes','Reduction'],['60%','76,741.2','18.75%'],['80%','102,321.6','25.00%'],['100%','127,902.0','31.25%']],[176,192,148])
p('Legacy and first-year cost','sub')
p('The reuse model uses daily resident traversals × walking minutes × added shade × independently selected reuse sunlight factor × reuse days. It excludes the modeled event arrivals and queue benefit. At 180 assumed reuse days and reuse sunlight factor 1, the starting plan estimates 1,578,780 resident person-minutes avoided and the optimized plan 525,420. These are separate annual planning estimates, not measured benefits.')
p('The starting plan estimates $171,200 in first-year program cost across 12 event windows, versus $251,400 for the optimized plan. The calculation includes selected initial package spend, assumed maintenance, repeated queue operations and a $500 operating allowance per refill hub per event window. Costs exclude taxes, permitting, site works and contingencies. A plan with better event exposure reduction may cost more across a season.')
p('What has and has not been verified','sub')
p('<b>Verified:</b> reported baseline/portfolio arithmetic against application model output; transparent units; deterministic sensitivity; exact enumeration for the finite package catalog. The application includes reproducible exports with resolved scenario inputs, package catalog, sunlight profile and data versions.')
p('<b>Not field-validated:</b> visitor assignment, duration, shade coverage, effectiveness, refill operations, community use, actual vendor costs or benefits. Historical point temperatures are contextual and do not establish intervention efficacy. No customer contract, completed pilot, health outcome or production certification is claimed.')
p('Reproduction','sub')
p('Use model version 1.0.0 with default attendance 22,000, 15:00 arrival, 100% delivered effectiveness, $75,000 cap and 25% minimum community weighting. Export the starting plan JSON, run the optimizer and export again. Evaluate the fixed optimized portfolio at 60%, 80% and 100% effectiveness. Preserve the JSON snapshot and tagged model source with the results.')
p('Before physical deployment: verify route permissions, accessibility and egress, measure counts and queues, audit shade by time of day, obtain supplier quotes and operator sign-off. Thermal assessment should use appropriate on-site measurements such as WBGT when needed.','small')
page()
title('PILOT AND SOURCES','A commercial hypothesis we can test')
p('One buyer and a narrow first engagement','sub')
p('The beachhead is a venue or event operations team with repeated outdoor arrival planning. Proposed price: <b>$5,000 for an assisted two-event pilot</b>, then <b>$6,000 per year for one venue</b>. Hardware, installation and on-site operating staff are separate. These are hypotheses, not evidence of demand. Measure planning hours, accepted recommendations, data collection cost and paid renewal.')
p('The pilot and legacy owner','sub')
p('Days 1–30: observe the workflow and field-audit one venue. Days 31–60: obtain approval, plan and observe event one. Days 61–90: revise for event two, assign asset ownership and storage, document a community reuse destination and test renewal. No outreach, approved site, paid engagement or partner commitment is implied.')
p('Competitive position','sub')
p('ShadeMap already supports shadows and event planning. UrbanFootprint offers climate and community spatial analysis. ShadeShift tests a narrower purchase: an auditable allocation of intervention funds that an operator can review and reuse. Public data and a small optimizer alone provide little defensibility. Verified site constraints, actual costs and repeat deployment learning could become an advantage if pilots earn repeated use.')
p('Sources and access notes','sub')
refs=[
('H3AT / CAPA / HARC 2020 observations','https://www.arcgis.com/home/item.html?id=d8dd6004e1ab4dccbfb36a5992f480bc'),
('H3AT project data and campaign context','https://www.h3at.org/2024-campaign/2024-campaign-results'),
('METRO developer portal and static GTFS','https://api-portal.ridemetro.org/'),
('Official Houston World Cup transit overview','https://www.houstontx.gov/houston2026/pdfs/metro-map-overview.pdf'),
('Organizer source catalog','https://github.com/HoustonSI/WorldCupUSSpatialData101'),
('Open-Meteo historical API / ERA5 documentation','https://open-meteo.com/en/docs/historical-weather-api'),
('Open-Meteo terms','https://open-meteo.com/en/terms'),
('National Weather Service heat index','https://www.weather.gov/safety/heat-index'),
('ShadeMap existing event-planning tools','https://shademap.app/help/'),
('UrbanFootprint spatial analysis','https://urbanfootprint.com/platform/explorer/')]
for label,url in refs:p(f'<link href="{url}" color="#006c59"><u>{label}</u></link>','small')
p('Attribute Open-Meteo and ECMWF ERA5/Copernicus for the atlas. Open-Meteo free API access is for noncommercial use; commercial service requires appropriate paid access or self-hosting. Preserve METRO and H3AT/CAPA/HARC attribution and downstream terms. Organizer catalog licensing does not replace downstream dataset licenses. This project does not imply FIFA, Rice or source-provider endorsement.','small')
doc=SimpleDocTemplate(str(OUT/'ShadeShift-Methods-and-Results.pdf'),pagesize=(612,792),rightMargin=48,leftMargin=48,topMargin=45,bottomMargin=60,title='ShadeShift — Methods and Results',author='',subject='Anonymous judging brief, Track 3')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT/'ShadeShift-Methods-and-Results.pdf')
